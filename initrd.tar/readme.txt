This file was loaded from a USTAR tar archive embedded into the kernel binary.
